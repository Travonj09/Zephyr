package convolve;

/*
Members
tv_sec - Time interval, in seconds.
tv_usec- Time interval, in microseconds. This value is used in combination with the tv_sec 
member to represent time interval values that are not a multiple of seconds.
*/


public class timeval {
	public long tv_sec;
	public long tv_usec;
}
