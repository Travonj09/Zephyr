package convolve;

public class Convolution1D {
	public static void  main(String[] args)
	{
	    float in[] = {3, 4, 5, 0, 0};
	    float out[] = {0, 0, 0, 0, 0};
	    float k[] = {2,1};
	    int i;
	    
	    Timer t = new Timer();

	    t.start();
	    Boolean success = Convolution.convolve1D(in, out, 5, k, 2);
	    t.stop();

	    if(success) System.out.println("SUCCESS, Elapsed Time: " + t.getElapsedTimeInMicroSec() + "us\n");
	    else        System.out.println("FAILED\n");

	    System.out.println("INPUT\n");
	    for(i=0; i < 5; ++i)
	    {
	    	System.out.println(in[i]);
	    }
	    System.out.println("\n\n");

	    System.out.println("KERNEL\n");
	    for(i=0; i < 2; ++i)
	    {
	    	System.out.println(k[i]);
	    }
	    System.out.println("\n\n");

	    System.out.println("OUTPUT\n");
	    for(i=0; i < 5; ++i)
	    {
	    	System.out.println(out[i]);
	    }
	    System.out.println("\n");

	    //return 0;
	}
}
